#pragma once
//
//  test.h
//  Changmin's library
//
//  Created by �ְ�â�� on 2020/11/09.
//  Copyright 2020 �ְ�â��. All rights reserved.
//

#ifndef test_h
#define test_h

#define MAX_COUNT 50 // �ݺ����� Ƚ�� 

void COMPARE_test();
void SHIFT_test();
void REDUCTION_test();

void ADD_test();
void SUB_test();
void MUL_test();
void Karatsuba_test();

void SQU_test();

#endif /* test_h */